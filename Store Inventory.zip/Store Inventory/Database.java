public interface Database{

}
